set -x;
set -e;

tenantname="<tenantnamehere>"
apikey="<placeapikeyhere>"

sudo yum install docker -y
sudo service docker start
sudo usermod -a -G docker ec2-user
sudo chkconfig docker on
sudo curl -L https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo systemctl start docker

# Run Neosec-VAmpi
sudo docker login docker-registry.neosec.com -u "$tenantname" -p "$apikey"
sudo docker run -d -p 81:5000 -t docker-registry.neosec.com/vampi:latest

cd /wwt-lab-files/

sudo yum install python3-pip -y
sudo pip3 install -r requirements.txt

timeout=600  # timeout in seconds
end_time=$((SECONDS+timeout))

while [ $SECONDS -lt $end_time ]; do
    output=$(sudo neosec-node-manager neotok status --api-key "$apikey")
    collectorStatus=$(grep -Po '"collectorStatus": "\K[^"]*' <<< "$output")

    if [ "$collectorStatus" = "running" ]; then
        echo "Collector is running."
        break
    else
        echo "Collector is not running yet. Retrying in 1 second..."
        sleep 1
	    
    fi
done

if [ $SECONDS -ge $end_time ]; then
    echo "Timed out waiting for collector to start."
fi


NOW=$(date +"+%s")
MYIP=$(hostname -i)

export LAB_CREATION_TIME=${NOW}
export LAB_INSTANCE_IP=${MYIP}
python3 modify_sequences.py
cp modified_30d_traffic.txt benign_traffic/modified_30d_traffic.txt
python3 one_hour_traffic.py </dev/null &>/dev/null &
